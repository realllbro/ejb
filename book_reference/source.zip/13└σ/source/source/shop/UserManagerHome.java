package kr.co.hanbitbook.ejb.examples.shop;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface UserManagerHome extends javax.ejb.EJBHome {
  public UserManager create() throws CreateException, RemoteException;
}