package kr.co.hanbitbook.ejb.examples.shop;


public class CategoryDataBean implements java.io.Serializable{
        private String name;
        private String text;

        public String getName() {
                return name;
        }

        public String getText() {
                return text;
        }

        public void setName(String string) {
                name = string;
        }

        public void setText(String string) {
                text = string;
        }

}
