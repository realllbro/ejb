package kr.co.hanbitbook.ejb.guestbook;

public class GuestbookDataBean implements java.io.Serializable{
	private int seq;
	private String name;
	private String content;
	public GuestbookDataBean(){
		seq = 0;
		name = "";
		content = "";
	}

	public void setSeq(int seq){
		this.seq = seq;
	}
	public void setName(String name){
		this.name = name;
	}
	public void setContent(String content){
		this.content = content;
	}

	public int getSeq(){
		return seq;
	}

	public String getName(){
		return name;
	}

	public String getContent(){
		return content;
	}
}